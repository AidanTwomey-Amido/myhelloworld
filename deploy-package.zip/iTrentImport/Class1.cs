﻿using System;

namespace iTrentImport
{
    public class Class1
    {
    }
}
