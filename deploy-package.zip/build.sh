#!/bin/bash

#build handlers
dotnet build
dotnet publish -c release

#install zip
apt-get -qq update
apt-get -qq -y install zip

#create deployment package
pushd iTrentImport/bin/release/netcoreapp2.1/publish
zip -r ./deploy-package.zip ./*
popd
